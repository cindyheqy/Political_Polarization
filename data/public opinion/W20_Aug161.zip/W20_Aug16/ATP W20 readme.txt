PEW RESEARCH CENTER
Wave 20 American Trends Panel 
Dates: August 16-September 12, 2016
Mode: Web and Mail 
Language: English and Spanish
N=4,538

***************************************************************************************************************************

NOTES


Questionnaire and topline reflect questions presented in web mode. Mail mode questionnaires available upon request. 


The following variables are recoded based on open-end responses:
dtpres_oe1
dtpres_oe2
dtpres_oe3
hrcpres_oe1
hrcpres_oe2
hrcpres_oe3
hrccrn2_oe1
hrccrn2_oe2
hrccrn2_oe3
dtcrn2_oe1
dtcrn2_oe2
dtcrn2_oe3
viewhomosex_moreaccepting_OE1
viewhomosex_moreaccepting_OE2
viewhomosex_lessaccepting_OE1


***************************************************************************************************************************

WEIGHTS 


WEIGHT_W20 is the weight for the combined sample of all web and mail interviews. 
Data for all Pew Research Center reports are analyzed using this weight.



***************************************************************************************************************************
SYNTAX (if applicable)



