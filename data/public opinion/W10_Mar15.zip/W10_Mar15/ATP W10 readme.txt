PEW RESEARCH CENTER
Wave 10 American Trends Panel 
Dates: March 16-April 6, 2015
Mode: Web and Mail
Language: English and Spanish
N=3,147

***************************************************************************************************************************

NOTE


Questionnaire and topline reflect questions presented in web mode. Mail mode questionnaires available upon request. 


Six cases had invalid values for ALCOHOL_NUMBER_W10.  Five that had values of 0 and 1 that had the value 100 were recoded as 998, 
"Out of range".  


The following variables are recoded based on open-end responses:
MIP_W10OE_1
MIP_W10OE_2
MIP_W10OE_3
q2_1_W10oe_1
q2_2_w10oe_2
q2_3_w10oe_3
q3_1_w10oe_1
q3_2_w10oe_2
q3_3_w10oe_3


***************************************************************************************************************************
WEIGHTS 

WEIGHT_W10 is the weight for the combined sample of all web and mail interviews. 
Data for all Pew Research Center reports are analyzed using this weight.



***************************************************************************************************************************
SYNTAX (if applicable)
