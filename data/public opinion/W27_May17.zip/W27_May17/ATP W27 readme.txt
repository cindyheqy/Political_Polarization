PEW RESEARCH CENTER
Wave 27 American Trends Panel 
Dates: May 1 - May 15, 2017
Mode: Web 
Language: English and Spanish
N=4,135

***************************************************************************************************************************
NOTES

The following coded variables are included at the end of the dataset:
pos_m1_cars6
pos_m2_cars6
pos_m3_cars6
CARS6pos1
CARS6pos2
CARS6pos3
CARS6pos4
CARS6pos5
CARS6pos6
CARS6pos7
CARS6posOther
CARS6posREF
neg_m1_cars6
neg_m2_cars6
neg_m3_cars6
CARS6neg1
CARS6neg2
CARS6neg3
CARS6neg4
CARS6neg5
CARS6negOther
CARS6negREF
HIRING5pos_m1
HIRING5pos_m2
HIRING5pos_m3
HIRING5pos1
HIRING5pos2
HIRING5pos3
HIRING5pos4
HIRING5pos5
HIRING5posOTHER
HIRING5posREF
HIRING5neg_m1
HIRING5neg_m2
HIRING5neg1
HIRING5neg2
HIRING5neg3
HIRING5neg4
HIRING5neg5
HIRING5neg6
HIRING5negOTHER
HIRING5negREF
CAREGIV5pos_m1
CAREGIV5pos_m2
CAREGIV5pos_m3
caregiv5pos1
caregiv5pos2
caregiv5pos3
caregiv5pos4
caregiv5pos5
caregiv5pos6
caregiv5pos7
caregiv5pos8
caregiv5pos9
caregiv5pos10
caregiv5pos11
caregiv5posOther
caregiv5posREF
CAREGIV5neg_m1
CAREGIV5neg_m2
caregiv5neg1
caregiv5neg2
caregiv5neg3
caregiv5neg4
caregiv5neg5
caregiv5neg6
caregiv5neg7
caregiv5negOther
caregiv5negREF
WORKCAT_11
WORKCAT_12
WORKCAT_13
WORKCAT_14
WORKCAT_15
WORKCAT_16
WORKCAT_21
WORKCAT_22
WORKCAT_31
WORKCAT_41
WORKCAT_42
WORKCAT_43
WORKCAT_51
WORKCAT_61
WORKCAT_62
WORKCAT_63
WORKCAT_64
WORKCAT_65
WORKCAT_66
WORKCAT_67
WORKCAT_68
WORKCAT_23
WORKCAT_99


***************************************************************************************************************************
WEIGHTS 


WEIGHT_W27 is the weight for the sample. 
Data for all Pew Research Center reports are analyzed using this weight.



***************************************************************************************************************************
SYNTAX (if applicable)
