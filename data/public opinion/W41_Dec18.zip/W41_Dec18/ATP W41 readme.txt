﻿PEW RESEARCH CENTER
Wave 41 American Trends Panel 
Dates: December 11-December 23, 2018
Mode: Web

Sample: Subsample
Language: English and Spanish
N=2,524


***************************************************************************************************************************
WEIGHTS 


WEIGHT_W41 is the weight for the sample. Data for all Pew Research Center reports are analyzed using this weight.

***************************************************************************************************************************
Releases from this survey:

March 21, 2019 "Looking to the Future, Public Sees an America in Decline on Many Fronts"
https://www.pewsocialtrends.org/2019/03/21/public-sees-an-america-in-decline-on-many-fronts/

March 21, 2019 "Looking ahead to 2050, Americans are pessimistic about many aspects of life in U.S."
https://www.pewresearch.org/fact-tank/2019/03/21/looking-ahead-to-2050-americans-are-pessimistic-about-many-aspects-of-life-in-u-s/

April 11, 2019 "6 demographic trends shaping the U.S. and the world in 2019"
https://www.pewresearch.org/fact-tank/2019/04/11/6-demographic-trends-shaping-the-u-s-and-the-world-in-2019/

June 4, 2019 "A majority of Americans think abortion will still be legal in 30 years, but with some restrictions"
https://www.pewresearch.org/fact-tank/2019/06/04/a-majority-of-americans-think-abortion-will-still-be-legal-in-30-years-but-with-some-restrictions/

August 30, 2019 "5 facts about the abortion debate in America"
https://www.pewresearch.org/fact-tank/2019/08/30/facts-about-abortion-debate-in-america/
