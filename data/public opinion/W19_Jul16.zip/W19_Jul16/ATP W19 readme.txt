PEW RESEARCH CENTER
Wave 19 American Trends Panel 
Dates: July 12-August 8, 2016
Mode: Web and Mail
Language: English and Spanish
N=4,579

***************************************************************************************************************************

NOTES

Questionnaire and topline reflect questions presented in web mode. Mail mode questionnaires available upon request. 


***************************************************************************************************************************
WEIGHTS 


WEIGHT_W19 is the weight for the combined sample of all web and mail interviews. 
Data for all Pew Research Center reports are analyzed using this weight.


***************************************************************************************************************************
SYNTAX (if applicable)



