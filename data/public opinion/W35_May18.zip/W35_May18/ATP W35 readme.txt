PEW RESEARCH CENTER
Wave 35 American Trends Panel 
Dates: May 29-June 11, 2018
Mode: Web 
Sample: Full panel
Language: English and Spanish
N=4,594

***************************************************************************************************************************
NOTES

This dataset contains coded open-end responses for questions V1Q4, V2Q4, V3Q4, and V4Q4. Coded responses are included for up to five categories each for positive or negative responses given.


***************************************************************************************************************************
WEIGHTS 


WEIGHT_W35 is the weight for the sample. Data for all Pew Research Center reports are analyzed using this weight.



***************************************************************************************************************************
Releases from this survey:


June 28, 2018 "Public Attitudes Toward Technology Companies"
https://www.pewinternet.org/2018/06/28/public-attitudes-toward-technology-companies/

July 11, 2018 "Activism in the Social Media Age"
https://www.pewinternet.org/2018/07/11/activism-in-the-social-media-age/

August 15, 2018 "14% of Americans have changed their mind about an issue because of something they saw on social media"
https://www.pewresearch.org/fact-tank/2018/08/15/14-of-americans-have-changed-their-mind-about-an-issue-because-of-something-they-saw-on-social-media/

September 5, 2018 "Americans are changing their relationship with Facebook"
https://www.pewresearch.org/fact-tank/2018/09/05/americans-are-changing-their-relationship-with-facebook/

September 5, 2018 "Facebook users don�t understand how the sites news feed works" 
https://www.pewresearch.org/fact-tank/2018/09/05/many-facebook-users-dont-understand-how-the-sites-news-feed-works/

October 11, 2018 "How social media users have discussed sexual harassment since me too went viral"
https://www.pewresearch.org/fact-tank/2018/10/11/how-social-media-users-have-discussed-sexual-harassment-since-metoo-went-viral/

November 5, 2018 "Liberal Democrats more likely than other groups to be politically active on social media"
https://www.pewresearch.org/fact-tank/2018/11/05/liberal-democrats-more-likely-than-other-groups-to-be-politically-active-on-social-media/

November 7, 2018 "Many Turn to YouTube for Children�s Content, News, How-To Lessons"
https://www.pewinternet.org/2018/11/07/many-turn-to-youtube-for-childrens-content-news-how-to-lessons/

November 16, 2018 "Public Attitudes Toward Computer Algorithms"
https://www.pewinternet.org/2018/11/16/public-attitudes-toward-computer-algorithms/

January 16, 2019 "Facebook Algorithms and Personal Data"
https://www.pewinternet.org/2019/01/16/facebook-algorithms-and-personal-data/




