PEW RESEARCH CENTER
Wave 16 American Trends Panel 
Dates: April 5-May 2, 2016
Mode: Web and Mail 
Language: English and Spanish
N=4,685

***************************************************************************************************************************

NOTES


Questionnaire and topline reflect questions presented in web mode. Mail mode questionnaires available upon request. 


Point estimates for all People-Press questions will vary slightly from published reports because
published material was based on analysis conducted on combined W15/16 dataset:

Partisanship and Political Animosity in 2016
http://www.people-press.org/2016/06/22/partisanship-and-political-animosity-in-2016/



The following variables are recoded based on open-end responses:
DEM1_W16 (DEMNOMOE first choice)
DEM2_W16 (DEMNOMOE second choice)
REP1_W16 (REPNOMOE first choice)
REP2_W16 (REPNOMOE second choice)

***************************************************************************************************************************

WEIGHTS 

WEIGHT_FORM_W16 is the weight for the combined sample of all web and mail interviews. 
Data for all Pew Research Center reports are analyzed using this weight.


***************************************************************************************************************************
SYNTAX (if applicable)



