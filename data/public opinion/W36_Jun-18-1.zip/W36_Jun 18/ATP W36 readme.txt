PEW RESEARCH CENTER
Wave 36 American Trends Panel 
Dates: June 19-July 2, 2018
Mode: Web 
Sample: Full panel
Language: English and Spanish
N=4,587


***************************************************************************************************************************
NOTES

The following variables are included in the dataset as coded open end responses. Responses to the first three mentions have been included. 
WHYMOREF1_M1_W36
WHYMOREF1_M2_W36
WHYMOREF1_M3_W36

***************************************************************************************************************************
WEIGHTS 


WEIGHT_W36 is the weight for the sample. Data for all Pew Research Center reports are analyzed using this weight.

***************************************************************************************************************************
Releases from this survey:

July 17, 2018 "A third of U.S. adults say they have used fertility treatments or know someone who has"
http://www.pewresearch.org/fact-tank/2018/07/17/a-third-of-u-s-adults-say-they-have-used-fertility-treatments-or-know-someone-who-has/

July 26, 2018 "Most Americans say higher ed is heading in wrong direction, but partisans disagree on why"
http://www.pewresearch.org/fact-tank/2018/07/26/most-americans-say-higher-ed-is-heading-in-wrong-direction-but-partisans-disagree-on-why/

Aug. 22, 2018 "Most Americans say more women running for Congress is a good thing, as hope for a female president grows"
http://www.pewresearch.org/fact-tank/2018/08/22/most-americans-say-more-women-running-for-congress-is-a-good-thing/

Sept. 20, 2018 "Women and Leadership 2018"
http://www.pewsocialtrends.org/2018/09/20/women-and-leadership-2018/

Sept. 20, 2018 "Men, women differ over some qualities they see as essential for political and business leadership"
http://www.pewresearch.org/fact-tank/2018/09/20/men-women-differ-over-some-qualities-they-see-as-essential-for-political-and-business-leadership/

Sept. 25, 2018 "Many Americans say women are better than men at creating safe, respectful workplaces"
http://www.pewresearch.org/fact-tank/2018/09/25/many-americans-say-women-are-better-than-men-at-creating-safe-respectful-workplaces/

Dec. 18, 2018 "A record number of women will be serving in the new Congress"
http://www.pewresearch.org/fact-tank/2018/12/18/record-number-women-in-congress/

Jan. 30, 2019 "Partisans agree political leaders should be honest and ethical, disagree whether Trump fits the bill"
http://www.pewresearch.org/fact-tank/2019/01/30/partisans-agree-political-leaders-should-be-honest-and-ethical-disagree-whether-trump-fits-the-bill/

Feb. 4, 2019 "State of the Union 2019: How Americans see major national issues"
http://www.pewresearch.org/fact-tank/2019/02/04/state-of-the-union-2019-how-americans-see-major-national-issues/



