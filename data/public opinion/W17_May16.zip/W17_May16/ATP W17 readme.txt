PEW RESEARCH CENTER
Wave 17 American Trends Panel 
Dates: May 10-June 6, 2016
Mode: Web and Mail Language: English and Spanish
N=4,563

***************************************************************************************************************************

NOTES


Questionnaire and topline reflect questions presented in web mode. Mail mode questionnaires available upon request. 


The following variables are recoded based on open-end responses:
DEM1_W17 (DEMNOMOE first choice)
DEM2_W17 (DEMNOMOE second choice)



***************************************************************************************************************************

WEIGHTS 


WEIGHT_W17 is the weight for the combined sample of all web and mail interviews. 
Data for all Pew Research Center reports are analyzed using this weight.


***************************************************************************************************************************
SYNTAX (if applicable)


