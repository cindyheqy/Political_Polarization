PEW RESEARCH CENTER
Wave 38 American Trends Panel 
Dates: September 24-October 7,2018
Mode: Web
Language: English and Spanish
N= 10,682

***************************************************************************************************************************
NOTES

The original dataset contained a duplicate response from the same person. The duplicate was removed, reducing the
sample size in the final dataset by 1 from 10,683 to 10,682.



***************************************************************************************************************************
WEIGHTS 

WEIGHT_W38 is the weight for the sample. Data for all Pew Research Center reports are analyzed using this weight.

***************************************************************************************************************************
Releases from this survey:

October 15, 2018 "Little Partisan Agreement on the Pressing Problems Facing the U.S."
https://www.people-press.org/2018/10/15/little-partisan-agreement-on-the-pressing-problems-facing-the-u-s/

October 18, 2018 "Gun Policy Remains Divisive, But Several Proposals Still Draw Bipartisan Support"
https://www.people-press.org/2018/10/18/gun-policy-remains-divisive-but-several-proposals-still-draw-bipartisan-support/

October 29, 2018 "Elections in America: Concerns Over Security, Divisions Over Expanding Access to Voting"
https://www.people-press.org/2018/10/29/elections-in-america-concerns-over-security-divisions-over-expanding-access-to-voting/

November 5, 2018 "More Now Say It�s �Stressful� to Discuss Politics With People They Disagree With"
https://www.people-press.org/2018/11/05/more-now-say-its-stressful-to-discuss-politics-with-people-they-disagree-with/

January 17, 2019 "Generation Z Looks a Lot Like Millennials on Key Social and Political Issues"
http://www.pewsocialtrends.org/2019/01/17/generation-z-looks-a-lot-like-millennials-on-key-social-and-political-issues/

February 13, 2019 "8 facts about love and marriage in America"
http://www.pewresearch.org/fact-tank/2019/02/13/8-facts-about-love-and-marriage/

September 5, 2019 �About one-in-five U.S. adults know someone who goes by a gender-neutral pronoun�
https://www.pewresearch.org/fact-tank/2019/09/05/gender-neutral-pronouns/


***************************************************************************************************************************




